package com.example.demo;

public class doctor_table 
{
  
}
