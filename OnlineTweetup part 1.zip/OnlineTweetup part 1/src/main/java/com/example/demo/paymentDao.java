package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service
public class paymentDao implements paymentService{

	@Autowired
	paymentRepo pr;
	@Override
	public void get(payment p1)
	{
		pr.save(p1);
	}

	


}
