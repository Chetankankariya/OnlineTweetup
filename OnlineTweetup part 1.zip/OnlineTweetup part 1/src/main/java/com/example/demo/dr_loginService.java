package com.example.demo;

public interface dr_loginService {

	void get(dr_loginService l1);

	String getEmail();

	String getPassword();

	

	void setAttribute(String string, String email);

}
