package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service
public class dr_loginDao implements dr_loginService{

	
	@Autowired
	dr_loginRepo lr;
	
	

	@Override
	public void get(dr_loginService l1) {
		
		lr.save(l1);
	}



	@Override
	public String getEmail() {
		// TODO Auto-generated method stub
		return null;
	}



	@Override
	public String getPassword() {
		// TODO Auto-generated method stub
		return null;
	}



	@Override
	public void setAttribute(String string, String email) {
		// TODO Auto-generated method stub
		
	}



	

}
