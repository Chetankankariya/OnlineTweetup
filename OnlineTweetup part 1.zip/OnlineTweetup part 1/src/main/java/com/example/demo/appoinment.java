package com.example.demo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
@Entity
public class appoinment
{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	
	private int id;
	private String phonenumber;
	private String selectdoctors;
	private String choosedepartment;
	private String date;
	private String time;
	private String fullname;
	private String yourmessage;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getPhonenumber() {
		return phonenumber;
	}
	public void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}
	public String getSelectdoctors() {
		return selectdoctors;
	}
	public void setSelectdoctors(String selectdoctors) {
		this.selectdoctors = selectdoctors;
	}
	public String getChoosedepartment() {
		return choosedepartment;
	}
	public void setChoosedepartment(String choosedepartment) {
		this.choosedepartment = choosedepartment;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getFullname() {
		return fullname;
	}
	public void setFullname(String fullname) {
		this.fullname = fullname;
	}
	public String getYourmessage() {
		return yourmessage;
	}
	public void setYourmessage(String yourmessage) {
		this.yourmessage = yourmessage;
	}
	@Override
	public String toString() {
		return "appoinment [id=" + id + ", phonenumber=" + phonenumber + ", selectdoctors=" + selectdoctors
				+ ", choosedepartment=" + choosedepartment + ", date=" + date + ", time=" + time + ", fullname="
				+ fullname + ", yourmessage=" + yourmessage + "]";
	}
	
	
	
}