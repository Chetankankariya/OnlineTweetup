package com.example.demo;

import java.util.List;
import java.util.Objects;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class homeController
{    


    @Autowired
    appoinmentService as;
    
    @Autowired
	registrationService rs;
    
    @Autowired
   	paymentService ps;
       
    @Autowired
   	dr_loginService ls;
    
    @Autowired
   	AdminloginService ds;
    
    @RequestMapping("/index")
	 	public String one()
	 	{
	 		return "index";
	 	}
    @RequestMapping("/registration")
 	public String one2()
 	{
    	
 		return "registration";
 	}
    
    //HttpSession registartion page
  
    @RequestMapping("/datastore")
    public String no(@ModelAttribute("r1") registration r1)
    {
    	rs.get(r1);
    	return "redirect:/login";
    }
    @RequestMapping("/login_check")
    public String get(@ModelAttribute("l1") registration  l1,HttpSession s1)
    {
    	registration regi= new registration();
      	 String email = l1.getEmail();
      	 String password= l1.getPassword();
      	 registration logi= rs.check_user_regi(email,password);
      	 
      	if(Objects.nonNull(logi))
   	 {
   		 l1.setAttribute("email", email);
   	 return "redirect:/doctor";
   	 }
   	 else
   	 {
    		return "redirect:/login";
    }
    }
    @PostMapping("/registration")
    public String doctor(HttpServletRequest reg,ModelMap m)
    {	    	 HttpSession rs = reg.getSession(false);
		String email = (String) rs.getAttribute("email");
		if (email != null ) {
			List<registration> doctor=((registrationService) rs).display();
			m.addAttribute("doctor", doctor);
			return "redirect:/doctor";
		} 
		else 
		{

			return "redirect:/login";
		} 
		}
   
    
   
	     @RequestMapping("/login")
	 	public String three()
	 	{
	 		return "login";
	 	}
	        
		@RequestMapping("/signin")
		public String two()
		{
			return "signin";
		}
		@RequestMapping("/team")
		public String twog()
		{
			return "team";
		}
		@RequestMapping("/dashboard")
		public String twoh()
		{
			return "dashboard";
		}
		@RequestMapping("/about")
		public String four()
		{
			return "about";
		}
		@RequestMapping("/payment")
		public String four1()
		{
			return "payment";
			
		}
		@RequestMapping("/login1")
		public String four21()
		{
			return "login1";
			
		}
		@RequestMapping("/appoinment")
		public String five()
		{
			return "appoinment";
			
		}
		@RequestMapping("/blog-sidebar")
		public String set()
		{
			return "blog-sidebar";
		}
		
		@RequestMapping("/blog-single")
		public String test()
		{
			return "blog-single";
			}
		@RequestMapping("/confirmation")
		public String date()
		{
			return "confirmation";
			}
		@RequestMapping("/contact")
		public String gate()
		{
			return "contact";
			}
		@RequestMapping("/department")
		public String late()
		{
			return "department";
		}
		@RequestMapping("/department-single")
		public String mat()
		{
			return "department-single";
		}
		
		  @RequestMapping("/doctor")
		  public String nat()
		  {
			  return "doctor"; 
			  
		  }
		 
		
		@RequestMapping("/doctor-single")
		public String rat()
		{
			return "doctor-single";
		}
		@RequestMapping("/documentation")
		public String cat()
		{
			return "documentation";
		}
		@RequestMapping("/service")
		public String dog()
		{
			return "service";
		}
		@RequestMapping("/price")
		public String twe()
		{
			return "price";
		}
		@RequestMapping("/one")
		public String t()
		{
			return "one";
		}
		@RequestMapping("/two")
		public String tu()
		{
			return "two";
		}
		@RequestMapping("/three")
		public String tur()
		{
			return "three";
		}
		@RequestMapping("/four")
		public String tr()
		{
			return "four";
		}
		@RequestMapping("/five")
		public String tt()
		{
			return "five";
		}
		@RequestMapping("/six")
		public String tw()
		{
			return "six";
		}
		@RequestMapping("/seven")
		public String tq()
		{
			return "seven";
		}
			
		
		@RequestMapping("/eight")
		public String tte()
		{
			return "eight";
		}
		@RequestMapping("/nine")
		public String wt()
		{
			return "nine";
		}
		@RequestMapping("/ten")
		public String tl()
		{
			return "ten";
		}
		@RequestMapping("/eleven")
		public String tm()
		{
			return "eleven";
		}
		@RequestMapping("/logout")
		public String tmr()
		{
			return "logout";
		}
		@RequestMapping("/profile")
		public String profile()
		{
			return "profile";
		}
		
		
//admin login 		
		@RequestMapping("/Admin_login")
		public String tmr2()
		{
			return "Admin_login";
		}
		
		/*@RequestMapping("/admin")
	    public String no(@ModelAttribute("r1") Adminlogin d1)
	    {
	    	ds.get(d1);
	    	return "redirect:/dashboard";
	    }*/
		
		@RequestMapping("/admin")
		public String AdminLogin1(@RequestParam ("name") String name,@RequestParam ("password") String password, ModelMap m,@ModelAttribute("Al") Adminlogin dl) {
			if((name.equals("dk@gmail.com") && password.equals("1234")) || (name.equals("dk@gmail.com") && password.equals("12345")))  
			{
				return "profile";
			}
			m.put("errorMsg", "Please provide correct Admin name and password !!");
			return "Admin_login";	
		}
		
		
		//payment creating............................................................................................
		
		

		@RequestMapping("/next2")
	 	public String set(@ModelAttribute("a1")appoinment a1)
	 	{
	 		as.get(a1);
 		return "redirect:/payment";
 	}
	    @RequestMapping("/offline_pay")
		
		public String offline()
		{
			return "offline_pay";
			
		}
     @RequestMapping("/online_pay")

     public String online_pay()
     {
     	return "online_pay";
     	
     }
		
      @RequestMapping("/doctor_edit_data")
		
		public String Oparyment()
		{
			return "doctor_edit_data";
			
		}
		
		
		//PATIENT EDIT AND DELETE START ...........,,,,,,,,,,,,,,,,,,,,,,,,.....................-------------------____________,,

		@RequestMapping("/regitration_edit")
		public String PData(ModelMap m)
		{
			List<registration>sp=rs.display();
			m.addAttribute("sp", sp);
			return "regitration_edit";
		}
		@RequestMapping("/registration_edit_data")
		public String Pedit(@RequestParam ("id") int id,ModelMap model)
		{
			Object regitration_edit =rs.getdataone(id);
			model.addAttribute("regitration_edit", regitration_edit);
			
			return "redirect:/registration_edit_data";
		}
		@RequestMapping("/pedit")
		public String PEdit(@ModelAttribute("p1") registration p1)
		{
			rs.get(p1);
			return "redirect:/regitration_edit";
		}
		
		@GetMapping("/registration_delete_data")
		public String Pdel(@RequestParam("id")int id)
		{
			rs.registration_delete_data(id);
			return "redirect:/regitration_edit";
		}
		
//Appoinment EDIT AND DELETE START .......
		
		@RequestMapping("/appoinment_edit")
		public String CAdata(ModelMap m)
		{
			List<appoinment>dk= as.display();
			m.addAttribute("dk",dk);
			return "/appoinment_edit";
		}
		
		@RequestMapping("/appoinment_edit_data")
		public String cedit(@RequestParam ("id") int id,ModelMap model)
		{
			 Object appoinment_edit =as.getdataone(id);
			model.addAttribute("appoinment_edit", appoinment_edit);
			return "appoinment_edit_data";
		}
		@PostMapping("/demo")
		public String updatecristana(@ModelAttribute ("a1")appoinment a1)
		{
			as.get(a1);
			return "redirect:/appoinment_edit";
		}
		@RequestMapping("/appoinment_delete_data")
		public String cdelete(@RequestParam("id")int id)
		{
			as.appoinment_delete_data(id);
			return "redirect:/appoinment_edit";
		}	
		
		//schedule
		@RequestMapping("/schedule")
		public String schedule()
		{
			return "schedule";
		}
		@PostMapping("/final")
		
	    public String Onpayment()
		{
			return "final";
				
		}
		
		@RequestMapping("/final")
		public String data1(@ModelAttribute("p1") payment p1)
		{
			ps.get(p1);
			return "redirect:/final";
		}
		
}
