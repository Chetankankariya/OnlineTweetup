package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AdminloginDao implements AdminloginService{

	@Autowired
	AdminloginRepo dr;
	
	public void get(Adminlogin d1)
	{
		dr.save(d1);
	}

	@Override
	public List<com.example.demo.appoinment> appoinment() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object getdataone(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void appoinment_delete(int id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Adminlogin> getdata() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Adminlogin> dispagent() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteadmin(int id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void getinfo(Adminlogin al) {
		// TODO Auto-generated method stub
		
	}
}
