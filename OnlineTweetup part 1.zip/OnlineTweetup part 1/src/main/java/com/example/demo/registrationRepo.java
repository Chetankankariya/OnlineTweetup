package com.example.demo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
@Repository
public interface registrationRepo extends JpaRepository<registration,Integer>{

	registration findByEmailAndPassword(String email, String password);

}
