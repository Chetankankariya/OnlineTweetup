package com.example.demo;

public interface paymentService {

	void get(payment p1);

	

	
}
