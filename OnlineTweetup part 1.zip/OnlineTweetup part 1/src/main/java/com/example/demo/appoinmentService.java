package com.example.demo;

import java.util.List;

public interface appoinmentService 
{
	void get(appoinment a1);

	List<appoinment> fetchregistartion();

	List<appoinment> display();

	Object getdataone(int id);

	List<appoinment> appoinment();

	

	void appoinment_delete_data(int id);

	void deleteadmin(int id);

	

	
}
