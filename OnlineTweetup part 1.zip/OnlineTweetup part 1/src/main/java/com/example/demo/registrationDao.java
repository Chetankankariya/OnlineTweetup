package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service
public class registrationDao implements registrationService{

	
	@Autowired
	registrationRepo rr;

	@Override
	public void get(registration r1) {
		rr.save(r1);
		
	}
	@Override
	public List<registration> display() {
		
		return rr.findAll();
	}
    
	@Override
	public void registration_delete_data(int id) {
		rr.deleteById(id);
		
	}
	@Override
	public Object getdataone(int id) {
		
		return rr.getById(id);
	}
	@Override
	public registration check_user_regi(String email, String password) {
		registration px=rr.findByEmailAndPassword(email,password);
		return px;
	}
	@Override
	public Object getdataone(registration r1) {
		return rr.save(r1);
		
	}
	@Override
	public void upload(registration dR) {
	
		
	}
	@Override
	public void patient_delete_data(int id) {
		rr.deleteById(id);
		
	}

}
