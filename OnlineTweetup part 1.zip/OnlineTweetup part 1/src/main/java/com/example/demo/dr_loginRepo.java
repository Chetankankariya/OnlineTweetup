package com.example.demo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
@Repository
public interface dr_loginRepo extends JpaRepository<dr_login,Integer> {

	void save(dr_loginService l1);

	

}
