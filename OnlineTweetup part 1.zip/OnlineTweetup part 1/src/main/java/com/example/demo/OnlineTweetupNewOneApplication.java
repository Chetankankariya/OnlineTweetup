package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineTweetupNewOneApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineTweetupNewOneApplication.class, args);

	
	
	}

}
