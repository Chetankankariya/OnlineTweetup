package com.example.demo;

import java.util.List;

public interface AdminloginService {

	void get(Adminlogin d1);

	List<appoinment> appoinment();

	Object getdataone(int id);

	void appoinment_delete(int id);

	List<Adminlogin> getdata();

	List<Adminlogin> dispagent();

	void deleteadmin(int id);

	void getinfo(Adminlogin al);

	

}
