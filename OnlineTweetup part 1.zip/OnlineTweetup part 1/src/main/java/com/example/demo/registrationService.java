package com.example.demo;

import java.util.List;

public interface registrationService {
	
	void upload(registration dR);
	List<registration> display();

	

	

	Object getdataone(registration r1);

	void patient_delete_data(int id);


	registration check_user_regi(String email, String password);

	Object getdataone(int id);





	void get(registration r1);
	void registration_delete_data(int id);

	

	
	
}
